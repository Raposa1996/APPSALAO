package com.appsalao;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Cadastre_se extends AppCompatActivity implements View.OnClickListener {
    EditText txtCADNome,txtCADCpf,txtCADEmail,txtCADSenha1,txtCADSenha2;
    Button btSalvarCadastre_se;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastre_se);

        txtCADNome   = (EditText)  findViewById(R.id.txtCADNome);
        txtCADCpf    = (EditText) findViewById(R.id.txtCADCpf);
        txtCADEmail  = (EditText) findViewById(R.id.txtCADEmail);
        txtCADSenha1 = (EditText) findViewById(R.id.txtCADSenha1);
        txtCADSenha2 = (EditText) findViewById(R.id.txtCADSenha2);
        btSalvarCadastre_se = (Button) findViewById(R.id.btSalvarCadastre_se);

        btSalvarCadastre_se.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(valiDados()==true){
            //gravar os dados
            SalvarDados();
        }
    }
    public void SalvarDados() {
        String msg = "";
        String txtNome = txtCADNome.getText().toString();
        String txtCpf = txtCADCpf.getText().toString();
        String txtEmail = txtCADEmail.getText().toString();
        String txtSenha = txtCADSenha1.getText().toString();

        BancoController bd = new BancoController(getBaseContext());
        String resultado;

        resultado = bd.insereDadosUsuario(txtNome, txtCpf, txtEmail, txtSenha);

        Toast.makeText(getApplicationContext(), resultado, Toast.LENGTH_LONG).show();
        //limpar();
    }


    public boolean valiDados(){
        String msg ="";
        Boolean retorno = true;
        if (txtCADNome.getText().length()==0){
            msg ="Atenção - o campo Nome deve ser preenchido!";
            Toast.makeText(getApplicationContext(),msg, Toast.LENGTH_LONG).show();
            retorno = false;
        }
        if (txtCADCpf.getText().length()==0){
            msg ="Atenção - o campo CPF deve ser preenchido!";
            Toast.makeText(getApplicationContext(),msg, Toast.LENGTH_LONG).show();
            retorno = false;
        }
        if (txtCADEmail.getText().length()==0){
            msg ="Atenção - o campo E-mail deve ser preenchido!";
            Toast.makeText(getApplicationContext(),msg, Toast.LENGTH_LONG).show();
            retorno = false;
        }
        if (txtCADSenha1.getText().length()==0 || txtCADSenha2.getText().length()==0){
            msg ="Atenção - o campo Senha e Comfirma Senha devem ser preenchidos!";
            Toast.makeText(getApplicationContext(),msg, Toast.LENGTH_LONG).show();
            retorno = false;
        }
        if (!txtCADSenha1.getText().toString().equals(txtCADSenha2.getText().toString())){
            msg ="Atenção - As duas senhas não estão iguais, digite novamente!";
            Toast.makeText(getApplicationContext(),msg, Toast.LENGTH_LONG).show();
            retorno = false;
        }
        return retorno;
    }
}